﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using AgiliTrain.PhoneyTools;

namespace PhoneyTools.Example
{
  public partial class MainPage : PhoneApplicationPage
  {
    // Constructor
    public MainPage()
    {
      InitializeComponent();

    }

    private void simpleMessageButton_Click(object sender, RoutedEventArgs e)
    {
      FadingMessage.ShowTextMessage("Saved...");
    }

    private void longMessageButton_Click(object sender, RoutedEventArgs e)
    {
      FadingMessage.ShowTextMessage("This is a big deal that should be testing the entire message size of the page.");
    }

    private void customMessageButton_Click(object sender, RoutedEventArgs e)
    {
FadingMessage msg = new FadingMessage()
{
  MessageToShow = theMessage,
  VerticalAlignment = VerticalAlignment.Top,
  HorizontalAlignment = HorizontalAlignment.Right
};
msg.Show(3000); // 3 seconds


    }

    private void shortenButton_Click(object sender, RoutedEventArgs e)
    {
      BitlyHelper.SetCredentials(apiKeyBox.Text, userNameBox.Text);
      BitlyHelper.Shorten(urlBox.Text, (result, error) =>
        {
          if (error != null)
          {
            FadingMessage.ShowTextMessage("Error Shortening Url: {0}", error.Message);
          }
          else
          { 
            FadingMessage.ShowTextMessage(result, 3000);
          }
        });
    }
  }
}