﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using AgiliTrain.PhoneyTools;

namespace PhoneyTools.Tests.Tests
{
  [TestClass]
  public class TestBitlyHelper
  {
    [TestMethod]
  [Priority(1)]
    public void TestNoCredentials()
    {
      BitlyHelper.Shorten("http://wildermuth.com", (result, exception) =>
        {
          Assert.IsInstanceOfType(exception, typeof(InvalidOperationException));
        });
    }

    [TestMethod]
    [Priority(1)]
    [ExpectedException(typeof(ArgumentException))]
    public void TestEmptyCredentials()
    {
      BitlyHelper.SetCredentials(null, null);
    }

    [TestMethod]
    [Priority(1)]
    [ExpectedException(typeof(ArgumentException))]
    public void TestEmptyUserID()
    {
      BitlyHelper.SetCredentials("BADAPIKEY", null);
    }

    [TestMethod]
    [Priority(1)]
    [ExpectedException(typeof(ArgumentException))]
    public void TestEmptyAppID()
    {
      BitlyHelper.SetCredentials(null, "BADUSERID");
    }

  }
}
