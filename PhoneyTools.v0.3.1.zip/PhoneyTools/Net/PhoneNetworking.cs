﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Net.NetworkInformation;

namespace AgiliTrain.PhoneyTools.Net
{
  /// <summary>
  /// Allows for detecting the type of 
  /// networking the phone is currently using.
  /// </summary>
  public static class PhoneNetworking
  {
    /// <summary>
    /// Networking Types
    /// </summary>
    public enum NetworkType
    {
      /// <summary>
      /// Unknown Network Type
      /// </summary>
      Unknown,
      /// <summary>
      /// No Network
      /// </summary>
      None,
      /// <summary>
      /// WiFi Connection
      /// </summary>
      WiFi,
      /// <summary>
      /// 3G or CDMA Connection
      /// </summary>
      Cellular,
      /// <summary>
      /// Ethernet via USB Connection
      /// </summary>
      Desktop
    };

    /// <summary>
    /// Gets the type of the network.
    /// </summary>
    /// <returns>A valid NetworkType enumeration value.</returns>
    public static NetworkType GetNetworkType()
    {
      switch (NetworkInterface.NetworkInterfaceType)
      {
        case NetworkInterfaceType.None:
          return NetworkType.None;
        case NetworkInterfaceType.MobileBroadbandCdma:
        case NetworkInterfaceType.MobileBroadbandGsm:
          return NetworkType.Cellular;
        case NetworkInterfaceType.Wireless80211:
          return NetworkType.WiFi;
        case NetworkInterfaceType.Ethernet:
          return NetworkType.Desktop;
      }

      return NetworkType.Unknown;
    }
  }
}
